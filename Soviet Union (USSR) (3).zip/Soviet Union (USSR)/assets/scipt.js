// Handle page navigation
document.addEventListener("DOMContentLoaded", function () {
  const currentPage = parseInt(document.body.getAttribute("data-page")); // From body tag
  const totalPages = 5;

  const updateButtonStates = () => {
    if (currentPage === 1) {
      document.getElementById("prevBtn").disabled = true;
    }
    if (currentPage === totalPages) {
      document.getElementById("nextBtn").disabled = true;
    }

    const pageButtons = document.querySelectorAll(".page-button");
    pageButtons.forEach((btn) => {
      const pageNum = parseInt(btn.getAttribute("data-page"));
      if (pageNum === currentPage) {
        btn.classList.add("active-page");
      }
    });
  };

  // Navigation actions
  document.getElementById("prevBtn").addEventListener("click", () => {
    if (currentPage > 1) {
      window.location.href = `page${currentPage - 1}.html`;
    }
  });

  document.getElementById("nextBtn").addEventListener("click", () => {
    if (currentPage < totalPages) {
      window.location.href = `page${currentPage + 1}.html`;
    }
  });

  const pageButtons = document.querySelectorAll(".page-button");
  pageButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const pageNum = parseInt(btn.getAttribute("data-page"));
      if (pageNum !== currentPage) {
        window.location.href = `page${pageNum}.html`;
      }
    });
  });

  // Recopedia main URL button (edit URL in HTML or below if needed)
  document.getElementById("mainSiteBtn").addEventListener("click", () => {
    window.location.href = "https://your-recopedia-main-url-here.com";
  });

  updateButtonStates();
});
